#version 120
// ---------------------------------------------------------------
//  Soft Warm Shaders - settings (low defaults for weak PCs)
// ---------------------------------------------------------------

//#define SHADOWS                       // Soft block shadows (sun by day, moon by night)
#define SHADOW_QUALITY 0              // [0 1]
#define SHADOW_RES 128                // [128 256 512 768 1024 1536 2048]
//#define GODRAYS                     // Cheap light shafts
#define GODRAY_STRENGTH 0.35          // [0.10 0.20 0.35 0.50 0.70]
#define RAY_SAMPLES 6                 // [4 6 8 12]
#define SHADOW_DIST 32.0              // [16.0 32.0 48.0 64.0 96.0]
#define WARMTH 1.0                    // [0.0 0.5 1.0 1.5]
#define VIGNETTE                      // Soft vignette

const int   shadowMapResolution = SHADOW_RES;
const float shadowDistance      = SHADOW_DIST;
const float sunPathRotation     = -25.0;
const bool  shadowtex1Nearest   = true;


// Uniforms shared by all stages. Declared ONLY here, never again in other files.
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform vec3 upPosition;
uniform vec3 shadowLightPosition;
uniform float rainStrength;

// Colours below are authored in "display" space; buffers hold linear-ish (c*c).
vec3 lin(vec3 c) { return c * c; }

float sunHeight() { return dot(normalize(sunPosition), normalize(upPosition)); }
float dayFactor()  { return smoothstep(-0.18, 0.22, sunHeight()); }
float duskFactor() { float h = sunHeight(); return exp(-h * h * 14.0); }

// Sky gradient for a view-space direction (day / sunset / night, sun + moon glow)
vec3 skyColor(vec3 dir) {
    vec3 up = normalize(upPosition);
    float h = dot(dir, up);
    float sh = sunHeight();
    float day = dayFactor();
    float dusk = duskFactor();

    vec3 dayZ   = vec3(0.30, 0.52, 0.92);
    vec3 dayH   = vec3(0.93, 0.88, 0.80);
    vec3 duskZ  = vec3(0.28, 0.30, 0.58);
    vec3 duskH  = vec3(1.00, 0.58, 0.34);
    vec3 nightZ = vec3(0.015, 0.025, 0.075);
    vec3 nightH = vec3(0.07, 0.09, 0.18);

    vec3 zen = mix(nightZ, dayZ, day);
    vec3 hor = mix(nightH, dayH, day);
    zen = mix(zen, duskZ, dusk * 0.6);
    hor = mix(hor, duskH, dusk);

    vec3 sd = normalize(sunPosition);
    float sa = max(dot(dir, sd), 0.0);
    hor = mix(hor, vec3(1.0, 0.62, 0.36), dusk * sa * sa * 0.5);

    float t = exp(-max(h, 0.0) * 3.0);
    vec3 col = mix(zen, hor, t);

    float sunVis = smoothstep(-0.12, 0.08, sh);
    float sa2 = sa * sa; float sa4 = sa2 * sa2; float sa6 = sa4 * sa2;
    float sa12 = sa6 * sa6; float sa24 = sa12 * sa12; float sa48 = sa24 * sa24;
    col += vec3(1.0, 0.72, 0.42) * (sa6 * 0.25 + sa48 * 0.45) * sunVis * (0.6 + 0.4 * dusk);

    vec3 md = normalize(moonPosition);
    float ma = max(dot(dir, md), 0.0);
    float moonVis = smoothstep(0.08, -0.12, sh);
    float ma2 = ma * ma; float ma4 = ma2 * ma2; float ma8 = ma4 * ma4;
    float ma16 = ma8 * ma8; float ma32 = ma16 * ma16; float ma64 = ma32 * ma32;
    col += vec3(0.45, 0.55, 0.90) * (ma8 * 0.10 + ma64 * 0.18) * moonVis;

    float l = dot(col, vec3(0.333));
    col = mix(col, vec3(l) * vec3(0.80, 0.84, 0.92), rainStrength * 0.8);
    return col;
}

// Colour of the shadow-casting light (sun by day, moon by night)
vec3 lightColor() {
    float sunSel = smoothstep(-0.03, 0.03, sunHeight());
    float dusk = duskFactor();
    vec3 sunC  = mix(vec3(1.08, 0.94, 0.74), vec3(1.15, 0.62, 0.30), dusk);
    vec3 moonC = vec3(0.17, 0.22, 0.45);
    return mix(moonC, sunC, sunSel);
}

// Fades to zero when the shadow light touches the horizon, so the sun->moon switch never pops
float lightAmount() {
    float lh = dot(normalize(shadowLightPosition), normalize(upPosition));
    return smoothstep(0.0, 0.28, lh) * (1.0 - rainStrength * 0.75);
}

// Soft ambient light (cool lifted shadows by day, deep blue at night)
vec3 ambientColor() {
    float day = dayFactor();
    float dusk = duskFactor();
    vec3 a = mix(vec3(0.050, 0.065, 0.140), vec3(0.50, 0.57, 0.72), day);
    a = mix(a, vec3(0.55, 0.42, 0.48), dusk * 0.5);
    float l = dot(a, vec3(0.333));
    a = mix(a, vec3(l), rainStrength * 0.5) * (1.0 - 0.25 * rainStrength);
    return a;
}


uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform float aspectRatio;

varying vec2 texcoord;
varying vec3 lightScreen;
varying vec3 rayCol;

void main() {
    vec3 c = texture2D(colortex0, texcoord).rgb;
    float noise = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));

#ifdef GODRAYS
    // light shafts: RAY_SAMPLES depth taps marching toward the light, sky = light gets through
    if (lightScreen.z > 0.5 && dot(rayCol, vec3(1.0)) > 0.01) {
        vec2 delta = lightScreen.xy - texcoord;
        float distL = length(delta * vec2(aspectRatio, 1.0));
        float fall = clamp(1.0 - distL * 0.9, 0.0, 1.0);
        fall *= fall;
        if (fall > 0.0) {
            float acc = 0.0;
            for (int i = 0; i < RAY_SAMPLES; i++) {
                float f = (float(i) + noise) / float(RAY_SAMPLES);
                vec2 p = texcoord + delta * f * 0.85;
                float inside = step(0.0, p.x) * step(p.x, 1.0) * step(0.0, p.y) * step(p.y, 1.0);
                acc += step(0.9999, texture2D(depthtex0, p).r) * inside;
            }
            c += rayCol * (acc / float(RAY_SAMPLES)) * fall;
        }
    }
#endif

    // gentle tonemap, then back to display space
    c = c * 1.5 / (c * 1.5 + 0.55);   // cheap soft tonemap (no exp)
    c = sqrt(c);

    // slightly richer colours, warm by day and cool at night, lifted soft blacks
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, 1.06);
    float day = dayFactor();
    c *= mix(vec3(0.96, 0.99, 1.06), vec3(1.0) + vec3(0.04, 0.0, -0.07) * WARMTH, day);
    c = c * 0.96 + vec3(0.018, 0.019, 0.024);

#ifdef VIGNETTE
    float v = length((texcoord - 0.5) * vec2(aspectRatio, 1.0));
    c *= 1.0 - 0.22 * smoothstep(0.35, 1.0, v);
#endif

    c += (noise - 0.5) / 255.0;   // hides banding in the smooth sky

    gl_FragData[0] = vec4(c, 1.0);
}
